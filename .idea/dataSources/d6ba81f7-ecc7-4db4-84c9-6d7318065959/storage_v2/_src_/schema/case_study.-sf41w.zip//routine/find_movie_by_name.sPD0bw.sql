create
    definer = root@localhost procedure find_movie_by_name(IN words varchar(50))
BEGIN
select name,id,poster from movies
where name like concat('%',words,'%');
END;

