create
    definer = root@localhost procedure find_all_customer()
BEGIN
select * from customers;
END;

