create
    definer = root@localhost procedure find_movie_by_category(IN category_find_id int)
BEGIN
select movies.name, categories.name category, poster,movies.id
from movies,categories,original
where categories.id = category_id and movies.id = movie_id and categories.id=category_find_id;
END;

