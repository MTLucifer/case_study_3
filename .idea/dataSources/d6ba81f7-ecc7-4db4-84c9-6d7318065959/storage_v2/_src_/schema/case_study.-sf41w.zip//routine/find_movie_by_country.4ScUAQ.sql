create
    definer = root@localhost procedure find_movie_by_country(IN c_id int)
BEGIN
select name, poster, id
from movies where country_id = c_id;
END;

