create
    definer = root@localhost procedure create_movie(IN mov_name varchar(225), IN mov_country_id int, IN mov_imdb float,
                                                    IN mov_poster varchar(225), IN mov_trailer varchar(50),
                                                    IN mov_desc longtext)
BEGIN
insert into movies( name,country_id,imdb,poster,trailer,description)
values (mov_name,mov_country_id,mov_imdb,mov_poster,mov_trailer,mov_desc);
END;

