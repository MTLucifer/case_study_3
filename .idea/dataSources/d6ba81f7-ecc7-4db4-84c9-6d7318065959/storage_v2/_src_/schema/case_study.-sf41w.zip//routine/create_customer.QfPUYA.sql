create
    definer = root@localhost procedure create_customer(IN cus_phone varchar(50), IN cus_name varchar(50),
                                                       IN cus_facility varchar(50))
BEGIN
insert into customers( phone,name,facility)
values (cus_phone,cus_name,cus_facility);
END;

