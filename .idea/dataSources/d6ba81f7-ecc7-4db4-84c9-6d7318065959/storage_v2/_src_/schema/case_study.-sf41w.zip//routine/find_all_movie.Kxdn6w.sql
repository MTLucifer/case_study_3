create
    definer = root@localhost procedure find_all_movie()
BEGIN
select movies.name,poster,movies.id,imdb,countries.name country,country_id
from movies join countries on movies.country_id=countries.id; 
END;

