create
    definer = root@localhost procedure delete_customer(IN customer_id int)
BEGIN
DELETE FROM `case_study`.`customers` WHERE (`id` = customer_id);
END;

