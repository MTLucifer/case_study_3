create
    definer = root@localhost procedure find_customer_by_id(IN customer_id int)
BEGIN
select * from customers
where id = customer_id;
END;

