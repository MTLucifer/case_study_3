create
    definer = root@localhost procedure delete_movie(IN mov_id int)
BEGIN
DELETE FROM `case_study`.`movies` WHERE (`id` = mov_id);
END;

